# Jenkins Webhook Demo App

This is a simple web app used to demonstrate:
GitHub → Jenkins Webhook → CI Pipeline

Steps:
1. Push code to GitHub
2. GitHub webhook triggers Jenkins
3. Jenkins pipeline runs automatically
